package Homework_Week1;

public class Program8_Divide {

    public static void main(String[] args) {
        System.out.println(50 / 3);
        System.out.println(16);

    }
}
