package Homework_Week1;

public class Program7_Sum {
    public static void main(String[] args){
        System.out.println(74+ 36);
        System.out.println(110);


    }
}
