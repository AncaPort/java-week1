package Homework_Week1;

public class Program6_Flag {

    public static void main(String[] args){
        System.out.println("****** ================================");
        System.out.println(" ***** ================================");
        System.out.println("****** ================================");
        System.out.println(" ***** ================================");
        System.out.println("****** ================================");
        System.out.println(" ***** ================================");
        System.out.println("****** ================================");
        System.out.println(" ***** ================================");
        System.out.println("****** ================================");
        System.out.println("=======================================");
        System.out.println("=======================================");
        System.out.println("=======================================");
        System.out.println("=======================================");
        System.out.println("=======================================");
        System.out.println("=======================================");
    }
}
