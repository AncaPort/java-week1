package Homework_Week1;

public class Program5_Triangle2 {

    public static void main(String[] args) {
        System.out.println("   * ");
        System.out.println("   ** ");
        System.out.println("   *** ");
        System.out.println("   **** ");
        System.out.println("  ****** ");
        System.out.println(" ******** ");
    }
}
