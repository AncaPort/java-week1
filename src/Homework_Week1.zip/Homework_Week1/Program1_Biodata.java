package Homework_Week1;

public class Program1_Biodata {

        public static void main(String[] args){
            System.out.println("Name            - Shital");
            System.out.println("Surname         - Sanghani");
            System.out.println("Address         - Harrow");
            System.out.println("BOD             - December");
            System.out.println("Nationality     - Indian");
            System.out.println("Sex             - Female");
            System.out.println("Religion        - Hindu");
            System.out.println("Language Known  - Gujarati,Hindi,English");
            System.out.println("Marital Status  - Married");
            System.out.println("Hobbies         - Music");

        }

}
