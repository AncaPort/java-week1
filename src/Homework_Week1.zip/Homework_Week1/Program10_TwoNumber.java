package Homework_Week1;

public class Program10_TwoNumber {

    public static void main(String[] args) {
        System.out.println(25);
        System.out.println(5);
        System.out.println(25 * 5);
    }
}